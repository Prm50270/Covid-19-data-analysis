#!/bin/bash
python3 q8.py
