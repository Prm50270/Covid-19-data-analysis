#!/bin/bash
python3 q7.py
