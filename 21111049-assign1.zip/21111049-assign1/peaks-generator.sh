#!/bin/bash
python3 q4.py
