#!/bin/bash
python3 q5.py
