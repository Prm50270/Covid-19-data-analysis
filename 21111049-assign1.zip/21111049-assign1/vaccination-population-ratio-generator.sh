#!/bin/bash
python3 q6.py
