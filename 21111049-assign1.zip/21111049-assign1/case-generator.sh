#!/bin/bash
python3 q3.py
