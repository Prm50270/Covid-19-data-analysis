#!/bin/bash

stime=`date +%s`
sh neighbor-districts-modified.sh;
sh edge-generator.sh;
sh case-generator.sh;
sh peaks-generator.sh;
sh vaccinated-count-generator.sh;
sh vaccination-population-ratio-generator.sh;
sh vaccine-type-ratio-generator.sh;
sh vaccinated-ratio-generator.sh;
sh complete-vaccination-generator.sh;
etime=`date +%s`

echo "Execution time is $((etime-stime)) seconds."
