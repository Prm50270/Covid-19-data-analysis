#!/bin/bash
python3 q2.py
